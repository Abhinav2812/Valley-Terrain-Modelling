# Valley-Terrain-Modelling
An opengl minor project for Computer Graphics Course (CS 352)
